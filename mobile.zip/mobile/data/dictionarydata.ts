import { DictionaryEntry } from "@/types";

export const PRESET_DICTIONARY: DictionaryEntry[] = [
  // ── BINA SHOHIH ──
  {
    id: "nasr",
    root: { fa: "ن", ain: "ص", lam: "ر" },
    babNum: 1,
    translation: "Menolong / Membantu",
    bina: "Shohih",
    masdar: "نَصْرًا",
    sifatMusyabihat: "نَاصِرٌ",
    notes: "Fi'il muta'addi. Contoh paling populer bab 1.",
  },
  {
    id: "dharb",
    root: { fa: "ض", ain: "ر", lam: "ب" },
    babNum: 2,
    translation: "Memukul / Memukulkan",
    bina: "Shohih",
    masdar: "ضَرْبًا",
    notes: "Simbol bab 2. Fi'il muta'addi.",
  },
  {
    id: "fath",
    root: { fa: "ف", ain: "ت", lam: "ح" },
    babNum: 3,
    translation: "Membuka / Menaklukkan",
    bina: "Shohih",
    masdar: "فَتْحًا",
    notes: "Bab 3 mensyaratkan ain atau lam berupa huruf halq.",
  },
  {
    id: "ilm",
    root: { fa: "ع", ain: "ل", lam: "م" },
    babNum: 4,
    translation: "Mengetahui / Memahami",
    bina: "Shohih",
    masdar: "عِلْمًا",
    sifatMusyabihat: "عَالِمٌ",
    notes: "Bab 4. Masdar 'ilm sangat populer.",
  },
  {
    id: "husn",
    root: { fa: "ح", ain: "س", lam: "ن" },
    babNum: 5,
    translation: "Menjadi Indah / Menjadi Baik",
    bina: "Shohih",
    masdar: "حُسْنًا",
    sifatMusyabihat: "حَسَنٌ",
    isLazim: true,
    notes: "Bab 5 selalu lazim (intransitif). Sifat musyabihat: حَسَنٌ",
  },
  {
    id: "karam",
    root: { fa: "ك", ain: "ر", lam: "م" },
    babNum: 5,
    translation: "Menjadi Mulia / Dermawan",
    bina: "Shohih",
    masdar: "كَرَمًا",
    sifatMusyabihat: "كَرِيمٌ",
    isLazim: true,
    notes: "Bab 5 lazim. Sifat musyabihat mengikuti wazan فَعِيلٌ.",
  },
  {
    id: "katab",
    root: { fa: "ك", ain: "ت", lam: "ب" },
    babNum: 1,
    translation: "Menulis / Menyurat",
    bina: "Shohih",
    masdar: "كِتَابَةً",
    masdarSamai: "كِتَابَةً",
    notes: "Masdar sama'i: كِتَابَةً. Qiyasi: كَتْبًا.",
  },
  {
    id: "jalas",
    root: { fa: "ج", ain: "ل", lam: "س" },
    babNum: 2,
    translation: "Duduk / Berdiam",
    bina: "Shohih",
    masdar: "جُلُوسًا",
    masdarSamai: "جُلُوسًا",
    notes: "Masdar sama'i: جُلُوسًا.",
  },
  {
    id: "dzahab",
    root: { fa: "ذ", ain: "ه", lam: "ب" },
    babNum: 3,
    translation: "Pergi / Berangkat",
    bina: "Shohih",
    masdar: "ذَهَابًا",
    masdarSamai: "ذَهَابًا",
    notes: "Masdar sama'i: ذَهَابًا.",
  },
  {
    id: "kharj",
    root: { fa: "خ", ain: "ر", lam: "ج" },
    babNum: 1,
    translation: "Keluar / Pergi Keluar",
    bina: "Shohih",
    masdar: "خُرُوجًا",
    masdarSamai: "خُرُوجًا",
    notes: "Masdar sama'i: خُرُوجًا.",
  },
  {
    id: "dakhl",
    root: { fa: "د", ain: "خ", lam: "ل" },
    babNum: 1,
    translation: "Masuk / Memasuki",
    bina: "Shohih",
    masdar: "دُخُولًا",
    masdarSamai: "دُخُولًا",
    notes: "Masdar sama'i: دُخُولًا.",
  },
  {
    id: "syarb",
    root: { fa: "ش", ain: "ر", lam: "ب" },
    babNum: 4,
    translation: "Minum / Meminum",
    bina: "Shohih",
    masdar: "شُرْبًا",
    notes: "Bab 4. Fathul-Ain pada fi'il madhi.",
  },
  {
    id: "qara",
    root: { fa: "ق", ain: "ر", lam: "أ" },
    babNum: 3,
    translation: "Membaca / Melantunkan",
    bina: "Shohih",
    masdar: "قِرَاءَةً",
    masdarSamai: "قِرَاءَةً",
    notes: "Lam fi'il berupa Hamzah. Masdar sama'i: قِرَاءَةً.",
  },
  {
    id: "nazr",
    root: { fa: "ن", ain: "ظ", lam: "ر" },
    babNum: 1,
    translation: "Melihat / Memandang",
    bina: "Shohih",
    masdar: "نَظَرًا",
    masdarSamai: "نَظَرًا",
    notes: "Masdar sama'i: نَظَرًا.",
  },
  {
    id: "farah",
    root: { fa: "ف", ain: "ر", lam: "ح" },
    babNum: 4,
    translation: "Gembira / Senang / Bahagia",
    bina: "Shohih",
    masdar: "فَرَحًا",
    sifatMusyabihat: "فَرِحٌ",
    notes: "Bab 4. Sifat musyabihat: فَرِحٌ (wazan فَعِلٌ).",
  },
  {
    id: "hasab",
    root: { fa: "ح", ain: "س", lam: "ب" },
    babNum: 6,
    translation: "Mengira / Menyangka / Berpikir",
    bina: "Shohih",
    masdar: "حِسَابًا",
    masdarSamai: "حِسَابًا",
    notes: "Bab 6 (Kasratani). Bab paling langka.",
  },
  // ── MITSAL WAWI (fa = و) ──
  {
    id: "wa'ad",
    root: { fa: "و", ain: "ع", lam: "د" },
    babNum: 2,
    translation: "Berjanji / Menjanjikan",
    bina: "Mitsal Wawi",
    asal: "وَعَدَ",
    madhi: "وَعَدَ",
    mudhari: "يَعِدُ",
    masdar: "وَعْدًا",
    masdarSamai: "عِدَةً",
    isimFail: "وَاعِدٌ",
    isimMaful: "مَوْعُودٌ",
    amr: "عِدْ",
    nahi: "لَا تَعِدْ",
    isimZamanMakan: "مَوْعِدٌ",
    explanation: "Huruf Waw (و) pada Fa' Fi'il gugur (mahdzuf) pada Fi'il Mudhari' Bab 2, karena ia Waw Mitsal jatuh setelah Fathah di antara dua Kasrah.",
    notes: "Contoh mitsal wawi bab 2 paling terkenal.",
  },
  {
    id: "wasal",
    root: { fa: "و", ain: "ص", lam: "ل" },
    babNum: 2,
    translation: "Sampai / Menyambung / Menghubungkan",
    bina: "Mitsal Wawi",
    asal: "وَصَلَ",
    madhi: "وَصَلَ",
    mudhari: "يَصِلُ",
    masdar: "وُصُولًا",
    masdarSamai: "صِلَةً",
    isimFail: "وَاصِلٌ",
    isimMaful: "مَوْصُولٌ",
    amr: "صِلْ",
    nahi: "لَا تَصِلْ",
    isimZamanMakan: "مَوْصِلٌ",
    explanation: "Huruf Waw (و) pada Fa' Fi'il gugur di mudhari' karena berada di antara fathah dan kasrah. Dalam madhi, waw tetap ada.",
    notes: "Mitsal wawi. Isim makan: مَوْصِلٌ (Mosul).",
  },
  // ── AJWAF WAWI (ain = و, menjadi ا) ──
  {
    id: "qawl",
    root: { fa: "ق", ain: "و", lam: "ل" },
    babNum: 1,
    translation: "Berkata / Berbicara / Mengatakan",
    bina: "Ajwaf Wawi",
    asal: "قَوَلَ",
    madhi: "قَالَ",
    mudhari: "يَقُولُ",
    masdar: "قَوْلًا",
    isimFail: "قَائِلٌ",
    isimMaful: "مَقُولٌ",
    amr: "قُلْ",
    nahi: "لَا تَقُلْ",
    isimZamanMakan: "مَقَالٌ",
    explanation: "Asal: قَوَلَ → I'lal: Waw (و) yang berharakat didahului fathah diubah menjadi Alif (ا) → قَالَ. Di mudhari', karena ain berharakat dammah, waw tetap sebagai waw: يَقُولُ.",
    notes: "Paradigma utama ajwaf wawi.",
  },
  // ── AJWAF YA'I (ain = ي, menjadi ا) ──
  {
    id: "bay",
    root: { fa: "ب", ain: "ي", lam: "ع" },
    babNum: 2,
    translation: "Menjual / Berdagang",
    bina: "Ajwaf Ya'i",
    asal: "بَيَعَ",
    madhi: "بَاعَ",
    mudhari: "يَبِيعُ",
    masdar: "بَيْعًا",
    isimFail: "بَائِعٌ",
    isimMaful: "مَبِيعٌ",
    amr: "بِعْ",
    nahi: "لَا تَبِعْ",
    isimZamanMakan: "مَبِيعٌ",
    explanation: "Asal: بَيَعَ → Ya' (ي) berharakat didahului fathah diubah menjadi Alif → بَاعَ. Di mudhari' bab 2 (kasri), ain mengikuti kasrah dan ya' kembali sebagai ya' panjang: يَبِيعُ.",
    notes: "Paradigma utama ajwaf ya'i bab 2.",
  },
  // ── NAQIS WAWI (lam = و) ──
  {
    id: "dua",
    root: { fa: "د", ain: "ع", lam: "و" },
    babNum: 1,
    translation: "Berdoa / Memanggil / Mengundang",
    bina: "Naqis Wawi",
    asal: "دَعَوَ",
    madhi: "دَعَا",
    mudhari: "يَدْعُو",
    masdar: "دُعَاءً",
    isimFail: "دَاعٍ",
    isimMaful: "مَدْعُوٌّ",
    amr: "اُدْعُ",
    nahi: "لَا تَدْعُ",
    isimZamanMakan: "مَدْعًى",
    explanation: "Asal: دَعَوَ → Waw (و) di Lam Fi'il berharakat didahului fathah diubah menjadi Alif → دَعَا. Di mudhari' (dhammi), waw tetap: يَدْعُو. Isim Fa'il: دَاعٍ (lam dibuang di akhir).",
    notes: "Contoh naqis wawi bab 1. Masdar berhamzah.",
  },
  // ── MUDHA'AF (ain = lam, diidghamkan) ──
  {
    id: "madd",
    root: { fa: "م", ain: "د", lam: "د" },
    babNum: 1,
    translation: "Memanjangkan / Mengulurkan / Membentangkan",
    bina: "Mudha'af",
    asal: "مَدَدَ",
    madhi: "مَدَّ",
    mudhari: "يَمُدُّ",
    masdar: "مَدًّا",
    isimFail: "مَادٌّ",
    isimMaful: "مَمْدُودٌ",
    amr: "مُدَّ",
    nahi: "لَا تَمُدَّ",
    isimZamanMakan: "مَمَدٌّ",
    explanation: "Asal: مَدَدَ → Ain dan Lam (dua Dal) berharakat sama dan berdampingan, diidghamkan: مَدَّ. Syarat idgham: ain berharakat, tidak dalam kelompok tertentu.",
    notes: "Mudha'af. Ain = Lam = د. Diidghamkan dengan shadda.",
  },
];

export function searchDictionary(entries: DictionaryEntry[], query: string): DictionaryEntry[] {
  if (!query.trim()) return entries;
  const q = query.toLowerCase().trim();
  return entries.filter((e) => {
    const rootConcat = `${e.root.fa}${e.root.ain}${e.root.lam}`;
    return (
      e.translation.toLowerCase().includes(q) ||
      rootConcat.includes(q) ||
      e.bina.toLowerCase().includes(q) ||
      (e.madhi || "").includes(q) ||
      (e.sifatMusyabihat || "").includes(q)
    );
  });
}

export function groupByBab(entries: DictionaryEntry[]): Record<number, DictionaryEntry[]> {
  const result: Record<number, DictionaryEntry[]> = { 1: [], 2: [], 3: [], 4: [], 5: [], 6: [] };
  entries.forEach((e) => {
    if (result[e.babNum]) result[e.babNum].push(e);
  });
  return result;
}

export function groupByBina(entries: DictionaryEntry[]): Record<string, DictionaryEntry[]> {
  const result: Record<string, DictionaryEntry[]> = {};
  entries.forEach((e) => {
    const key = e.bina || "Shohih";
    if (!result[key]) result[key] = [];
    result[key].push(e);
  });
  return result;
}

export function groupByHijaiyah(entries: DictionaryEntry[]): Record<string, DictionaryEntry[]> {
  const result: Record<string, DictionaryEntry[]> = {};
  entries.forEach((e) => {
    const key = e.root.fa.trim();
    if (!result[key]) result[key] = [];
    result[key].push(e);
  });
  return result;
}
